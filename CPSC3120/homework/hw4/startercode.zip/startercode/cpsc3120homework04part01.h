#ifndef CPSC3120HOMEWORK04PART01_H
#define CPSC3120HOMEWORK04PART01_H

#include <vector>

using namespace std;

int longestIncreasingSubsequence( vector<int> numbers );

#endif

