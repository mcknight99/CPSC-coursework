#include "cpsc3120homework04part01.h"
#include <vector>
#include <iostream>
#include <cstdio>

using namespace std;

int longestIncreasingSubsequence( vector<int> numbers ){
  return -1;
}
