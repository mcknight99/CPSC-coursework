#ifndef CPSC3120HOMEWORK04PART02_H
#define CPSC3120HOMEWORK04PART02_H

#include <vector>
#include <string>

using namespace std;

unsigned long long int minimumVotes( vector<unsigned long long> , vector<int> , vector<string> );

#endif

