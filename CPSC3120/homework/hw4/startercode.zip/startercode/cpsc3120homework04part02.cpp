#include "cpsc3120homework04part02.h"
#include <vector>
#include <climits>
#include <cstdio>
#include <iostream>
#include <cmath>
#include <string>

using namespace std;

unsigned long long int minimumVotes( vector<unsigned long long> votes , vector<int> ecVotes , vector<string> abbr ){
  return -1;
}
