#ifndef CPSC3120HOMEWORK03PART02_H
#define CPSC3120HOMEWORK03PART02_H
#include <vector>
using namespace std;

vector< vector<double> > allPairsSP( vector< vector<double> > , int );

#endif

