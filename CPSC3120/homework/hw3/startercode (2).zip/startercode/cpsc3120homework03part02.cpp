#include <vector>
#include "cpsc3120homework03part02.h"
#include <cmath>
#include <iostream>

using namespace std;

vector< vector<double> > allPairsSP( vector< vector<double> > adjacencyMatrix , int i ){
  int n = adjacencyMatrix.size();
  for( int i = 0; i < n; i++ ){
    for( int j = 0; j < n; j++ ){
      fprintf( stderr , "% +4.1f " , adjacencyMatrix[i][j] );
    }
    cerr << endl;
  }

  return adjacencyMatrix;
}
