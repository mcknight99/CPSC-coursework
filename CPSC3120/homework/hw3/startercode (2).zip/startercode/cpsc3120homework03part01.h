#ifndef CPSC3120HOMEWORK03PART01_H
#define CPSC3120HOMEWORK03PART01_H
#include <vector>
using namespace std;

double maximumST( vector< vector<double> > );

#endif

