#include <vector>
#include "cpsc3120homework03part01.h"
#include <cmath>
#include <iostream>
#include <cstdio>

using namespace std;

double maximumST( vector< vector<double> > adjacencyMatrix ){
  vector<int> row(adjacencyMatrix[0].size(),-1);
  vector< vector<int> > matrix(adjacencyMatrix.size(),row);
  cerr << matrix.size() << endl;
  cerr << matrix[0].size() << endl;
  for( int i = 0; i < matrix.size(); i++ ){
    for( int j = 0; j < matrix[0].size(); j++ ){
      fprintf( stderr , "% 2d " , matrix[i][j] );
    }
    cerr << endl;
  }
  return 42.0;
}
