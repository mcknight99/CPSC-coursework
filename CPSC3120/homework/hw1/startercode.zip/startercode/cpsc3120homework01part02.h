#ifndef CPSC3120HOMEWORK01PART02_H
#define CPSC3120HOMEWORK01PART02_H

#include <string>

using namespace std;

void removeConsonants( string& );

#endif

