#ifndef CPSC3120HOMEWORK01PART_H
#define CPSC3120HOMEWORK01PART_H

#include <vector>

using namespace std;

int maxSubSlow( const vector<int>& );
int maxSubFaster( const vector<int>& );
int maxSubFastest( const vector<int>& );

#endif

