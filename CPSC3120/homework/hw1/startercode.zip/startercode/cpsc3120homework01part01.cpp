#include "cpsc3120homework01part01.h"
#include <vector>
#include <cmath>

using namespace std;

int maxSubSlow( const vector<int> &numbers ){
  return 0;
}

int maxSubFaster( const vector<int> &numbers ){
  return 0;
}

int maxSubFastest( const vector<int> &numbers ){
  return 0;
}
