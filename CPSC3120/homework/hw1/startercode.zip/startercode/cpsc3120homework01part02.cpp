#include "cpsc3120homework01part02.h"
#include <string>

using namespace std;

void removeConsonants( string &word ){
  return;
}
