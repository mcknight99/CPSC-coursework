#ifndef PPMUTIL_H
#define PPMUTIL_H

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

typedef struct Pixel
{
    unsigned char r, g, b;
}pixel_t;

typedef struct Header
{
    char type[3];
    unsigned int width;
    unsigned int height;
    unsigned int maxVal;
}header_t;

//Your function prototypes will placed here.

#endif
